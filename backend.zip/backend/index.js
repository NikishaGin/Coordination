import express from "express"
import cors from "cors"
import { APP_CONFIG } from "./src/connection.js"
import baseRouter from "./src/modules/routes.js"
import { rootErrorHandler } from './middleware.js';


const app = express()

// Порядок прикрепления важен
app.use(
    cors({
        origin: "*",
        exposedHeaders: ["Content-Disposition"]
    }),
    express.json(),
)
app.use("/api-coordination", baseRouter)
app.use(rootErrorHandler,)


app.listen(
    APP_CONFIG.port, 
    APP_CONFIG.host,
    () => console.log(`Сервер запущен на http://${APP_CONFIG.host}:${APP_CONFIG.port}/ ...`)
)
