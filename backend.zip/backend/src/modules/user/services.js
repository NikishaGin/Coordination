import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import { phpToBcryptHash } from '../../utils/db_utils.js';
import { getUserByIdOrLogin } from '../../queries/selectors.js';


const SECRET_KEY = "i5n3b4f5br65HY567JHGFRHb55vgcfvghjkokm87654dse76UHYGF765tyhj&GvyHgfg6GBGV"
const EXPIRES_IN = "72h"


export const decodeToken = req => {
    try { 
        const token = req.headers?.authorization
        const payload = jwt.verify(token)

        return { isValid: true, payload }
    } catch(error) {
        return { isValid: false }
    }
}


export const isPasswordValid = (password, phpHash) => 
    bcrypt.compareSync(password, phpToBcryptHash(phpHash))


export const generateToken = payload => 
    jwt.sign(payload, SECRET_KEY, { expiresIn: EXPIRES_IN })


export const getUserByRequest = async req => {
    const { payload: { id } = {} } = decodeToken(req)
    const [ userData ] = await getUserByIdOrLogin({ id })
    return userData
}
