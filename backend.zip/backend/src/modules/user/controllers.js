import { decodeToken, generateToken, isPasswordValid } from './services.js';
import { getUserByIdOrLogin } from '../../queries/selectors.js';
import { errWrap } from '../../utils/controllers_utils.js';


export const loginUser = errWrap(async (req, res) => {
    const { login, password } = req.body

    if (!(login && password)) {
        res.status(400).json({ details: "Missing required fields: login and password" })
        return
    }

    const {
        passwordHash = "",  ...userData
    } = await getUserByIdOrLogin({ login }) || {}

    if (!passwordHash) {
        res.status(404).json({ details: "User not found", code: 1 })  // Не надо так, :<
        return
    }

    const isValid = isPasswordValid(password, passwordHash)
    if (!isValid) {
        res.status(403).json({ details: "Incorrect login or password", })
        return
    }

    const token = generateToken(userData)
    res.status(200).json({ ...userData, token })
})


export const verifyUser = errWrap(async (req, res) => {
    console.log("lol")
    const { isValid, payload } = decodeToken(req)
    res.json({ isVerify: isValid, exp: payload?.exp })
})
