import { serviceSelectors } from "../../queries/selectors.js"
import { isArchive, isDerivedDebt } from '../../utils/controllers_utils.js';


export const getRegions = (req, res, next) => {
    const page = req.params.page

    const is_derivative_debt = isDerivedDebt(page)
    const is_archive = isArchive(page)

    serviceSelectors
        .getRegions(is_derivative_debt, is_archive)
        .then(data => res.json(data))
        .catch(next)
}


export const getDebtTypes = (_, res, next) =>  {
    serviceSelectors
        .getDebtTypes()
        .then(data => res.json(
            data.map(item => item.debt_type)
        ))
        .catch(next)
}

export const checkServiceMode = (_, res, next) => 
    service
        .checkServiceMode()
        .then(([ data ]) => res.json(Boolean(data))) // ?
        .catch(next)


export const changeServiceMode = (_, res, next) => {
    service
        .changeServiceMode()
        .then(() => response.json({}))
        .catch(next)
}

