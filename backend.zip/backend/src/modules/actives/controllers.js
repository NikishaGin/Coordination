import { activesSelectors } from "../../queries/selectors.js"
import * as updates from "../../queries/updates.js"
import { fixInsertManyIdReturn } from '../../utils/db_utils.js';
import { errWrap, isArchive, isDerivedDebt } from '../../utils/controllers_utils.js';


export const getTables = (req, res) => {
    const { page, regionCode } = req.params

    const is_derivative_debt = isDerivedDebt(page)
    const is_archive = isArchive(page)

    activesSelectors
        .getTables(regionCode, is_derivative_debt, is_archive)
        .then(data => res.json(data))
        .catch(console.log)
}


export const getInfo = (req, res) => {
    const inn = req.params.inn

    activesSelectors
        .getInfo(inn)
        .then(([ data ]) => res.json(data))
        .catch(console.log)
}


export const getResolutions = (req, res) => {
    const inn = req.params.inn

    activesSelectors
        .getResolutions(inn)
        .then(data => res.json(data))
        .catch(console.log)
}


export const getActivesStatistics = errWrap(async (req, res) => {
    const inn = req.params.inn;
    const queries = activesSelectors.getActivesStatistics(inn);

        let total_sum = 0;
        const result = {};

        for (const [ active, query ] of Object.entries(queries)) {
            const [ data ] = await query;
            const cost = parseFloat(data?.cost ?? '0');

            total_sum += cost;
            result[active] = data;
        }

        result.total_sum = total_sum;
        res.json(result);
})


export const getDebt = (req, res, next) => {
    const inn = req.params.inn

    activesSelectors
        .getDebt(inn)
        .then(data => res.json(data))
        .catch(next)
}


export const getActives = (req, res, next) => {
    const { inn, nameActive } = req.params

    activesSelectors
        .getActives(inn, nameActive)
        .then(data => res.json(data))
        .catch(next)
}


export const createNewActives = (req, res, next) => {
    const { inn, nameActive } = req.params

    const userData = req.user
    const data = req.body

    updates
        .createNewActives(
            nameActive,  
            data, 
            { inn, id: userData.id, role: userData.role }
        )
        .then(([ id ]) => {
            const insertIds = fixInsertManyIdReturn(id, data.length)
            res.json(insertIds) // На фронте всегда ожидается массив
        })
        .catch(next)
}


export const updateActives = (req, res, next) => {
    const { inn, nameActive } = req.params

    const userData = req.user
    const data = req.body

    updates
        .updateActives(
            nameActive, 
            data,
            { inn, id: userData.id, role: userData.role }
        )
        .then(() => res.json({ details: "success" }))
        .catch(next)
}