import { Router } from 'express'
import * as controllers from "./controllers.js"
import { checkAuthMiddleware } from "../../../middleware.js";


const router = Router()

router.use(checkAuthMiddleware)

router.get("/get-statistics",    controllers.getSelectedDebtorsStat)
router.get("/get-statistics-IP", controllers.getSelectedDebtorsEnforcementStat)

export default router