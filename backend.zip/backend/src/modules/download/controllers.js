import { downloadSelectors } from "../../queries/selectors.js"
import { createSheet, sendXLSXFile, getDateNow } from "./tablesConfig/create.js"
import { headerStatisticsIP, headersStatistics } from "./tablesConfig/headers.js"
import { errWrap } from '../../utils/controllers_utils.js';


export const getSelectedDebtorsStat = errWrap(async(req, res) => {
    const { isDerived, regionCode, innList } = req.query

    const stats = await downloadSelectors.getStatistics(regionCode, innList, isDerived)
    const headers = headersStatistics(isDerived)

    const sheetNames = {
        general: "Статистика",
        actives: "Статистика по активам",
        debit:   "статистика по дебиторской задолженности"
    }

    const namedSheets = Object.entries(sheetNames).map(
        ([ type, name ]) => [
            name, 
            createSheet(stats[type], headers[type])
        ]
    );

    sendXLSXFile(
        res,
        Object.fromEntries(namedSheets),
        `Выгрузка_${regionCode}_${getDateNow()}.xlsx`
    );
})


export const getSelectedDebtorsEnforcementStat = errWrap(async (request, response) => {
    const { isDerived, regionCode, innList } = request.query

    const stats = await downloadSelectors.getStatisticsIP(regionCode, innList)

    const header = headerStatisticsIP(isDerived)
    const sheet = createSheet(stats, header)

    sendXLSXFile(
        response,
        { "Статистика": sheet },
        `Выгрузка_по_ИП_${regionCode}_${getDateNow()}.xlsx`
    )
})
