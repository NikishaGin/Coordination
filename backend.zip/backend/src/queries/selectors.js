import db from "../connection.js"
import * as subqueries from "./subqueries.js"
import { ACTIVES } from '../types.js';



const flagsMapping = {
    end_date:       "Окончено",
    stop_date:      "Приостановлено",
    pending_date:   "Отложено",
    terminate_date: "Прекращено",
    _:              "На исполнении"
}

const fields = ["transport_data", "nedvizh_data", "debit_data", "another_data"]


const joinActivesAndDebitTables = query =>
    query
        .leftJoin("debt_type", "debt_type.id", "meta.debt_type")
        .leftJoin(db.raw('(??) as resolutions_data', [subqueries.getResolutions]), 'meta.inn', 'resolutions_data.inn')
        .leftJoin(db.raw('(??) as transport_data', [subqueries.getActiveTable("transport")]), 'meta.inn', 'transport_data.inn')
        .leftJoin(db.raw('(??) as nedvizh_data', [subqueries.getActiveTable("property")]), 'meta.inn', 'nedvizh_data.inn')
        .leftJoin(db.raw('(??) as debit_data', [subqueries.getActiveTable("debit")]), 'meta.inn', 'debit_data.inn')
        .leftJoin(db.raw('(??) as another_data', [subqueries.getActiveTable("another")]), 'meta.inn', 'another_data.inn');


export const serviceSelectors = {
    getRegions(is_derivative_debt, is_archive) {
        return db('meta')
            .select(db.raw('DISTINCT meta.region AS regionCode'), 'regions.regionName AS regionName')
            .leftJoin('resolutions', 'meta.inn', 'resolutions.inn')
            .leftJoin('regions', db.raw('meta.region COLLATE utf8mb4_general_ci = regions.regionCode'))
            .where({
                'resolutions.is_derivative_debt': Number(is_derivative_debt),
                'resolutions.is_archive':         Number(is_archive)
            })
            .orderBy('meta.region', 'asc')
    },

    getDebtTypes() {
        return db("debt_type").select("debt_type");
    },

    checkServiceMode() {
        return db("settings").first("value")
    },

    async changeServiceMode() {
        let currValue = await db("settings").first("value")
        return await db("settings").update({
            value: !currValue.value
        })
    }
}


export const activesSelectors = {
    getTables(regionCode, is_derivative_debt, is_archive) {
        return db('meta')
            .select(db.ref("debt_type.debt_type").as("category"))
            .selectFromTable("meta", [ "inn", "name", "sosp_code" ])
            .selectFromTable("resolutions_data", [ "post_sum", "cur_debt", "sosp_code" ])

            .reduceFlagsToStatusField("resolutions_data", "status_ip", flagsMapping)
            .sumFieldsOfFewTables(fields, "total_sum")
            .sumFieldsOfFewTables(fields, "arrest")
            .sumFieldsOfFewTables(fields, "evaluation")
            .sumFieldsOfFewTables(fields, "realization_property")
            .sumFieldsOfFewTables(fields, "price_reduction")
            .sumFieldsOfFewTables(fields, "realization_sum_2")
            .sumFieldsOfFewTables(fields, "return_sum")
            .sumFieldsOfFewTables(fields, "total_sum")
            .select(db.ref(db.raw("IFNULL(debit_data.foreclose, 0.00)")).as("debitor"))
            .select(db.ref(db.raw("IFNULL(debit_data.foreclose, 0.00)")).as("debitor"))
            .modify(joinActivesAndDebitTables)
            .where({
                'meta.region': regionCode,
                'resolutions_data.is_derivative_debt': Number(is_derivative_debt),
                'resolutions_data.is_archive': Number(is_archive)
            })
            .groupBy('inn')
    },
    getInfo(inn) {
        return db('meta')
            .selectFromTable("meta", [
                "inn",
                "name",
                "category",
                "kno",
                "sosp_code",
                "exec_date"
            ])
            .leftJoin("debt_type", "debt_type.id", "meta.debt_type")
            .where("meta.inn", inn)
    },
    getResolutions(inn) {
        return db("resolutions")
            .selectFromTable("resolutions", [
                "resolutions_number",
                "resolutions_date",
                "resolutions_sum",
                "cur_debt",
                "exec_number",
                "exec_date"
            ])
            .where("resolutions.inn", inn)
    },
    getActivesStatistics(inn) {
        return {
            transport:
                db("transport")
                    .count({ count: "id" })
                    .sum({ cost: db.raw("IFNULL(cost, 0.00)") })
                    .where("inn", inn)
                    .andWhere("status", "<>", 2),
            property:
                db("property")
                    .count({ count: "id" })
                    .sum({ cost: db.raw("IFNULL(cost, 0.00)") })
                    .where("inn", inn)
                    .andWhere("status", "<>", 2)
                    .andWhere("type_id", 2),
            ground:
                db("property")
                    .count({ count: "id" })
                    .sum({ cost: db.raw("IFNULL(cost, 0.00)") })
                    .where("inn", inn)
                    .andWhere("status", "<>", 2)
                    .andWhere("type_id", 4),
            debit:
                db("debit")
                    .count({ count: "id" })
                    .sum({ cost: db.raw("IFNULL(total_sum, 0.00)") })
                    .where("inn", inn),
            another:
                db("another")
                    .count({ count: "id" })
                    .sum({ cost: db.raw("IFNULL(cost, 0.00)") })
                    .where("inn", inn)
        }
    },
    getDebt(inn) {
        return db("debit")
            .select(
                "id",
                "date",
                "debitor_names",
                "debitor_inn",
                "total_sum",
            )
            .where({ inn })
    },
    getActives(inn, nameActive) {
        const baseDataQuery = subqueries.getActivesDetails(nameActive)

        switch (nameActive) {
            case ACTIVES.Transport:
                return baseDataQuery
                    .select("number as state_number")
                    .where({
                        inn,
                        status: { "<>": 2 },
                    })

            case ACTIVES.Property:
            case ACTIVES.Ground:
                return baseDataQuery
                    .select(
                        "share_size",
                        "registration_start_date",
                        "registration_end_date",
                        "number as cadastral_number",
                    )
                    .where({
                        inn,
                        status: { "<>": 2 },
                        type_id: nameActive === "property" ? 2 : 4
                    })

            case ACTIVES.Debit:
                return baseDataQuery
                    .select(
                        "dz_foreclose_date",
                        "dz_foreclose_sum",
                        "dz_cancel_foreclose_date",
                        "dz_cancel_foreclose_sum",
                        "debitor_address",
                    )
                    .where("inn", inn);

            case ACTIVES.Another:
                return baseDataQuery.where({ inn });
        }

        throw new Error(
            `Incorect nameActive name, expected ${Object.keys(ACTIVES)} got ${nameActive}`
        );
    }
}


const buildCommonFieldsQuery = (
    withActives = true,
    withDebit = true,
    regionCode,
    innList
) => {
    const idFields = [ "meta.kno", "meta.inn", "meta.name" ];
    const sumFields = [ "resolutions.post_sum", "resolutions.curr_debt" ];

    const tables = [
        ...(withActives ? [
            ACTIVES.Transport,
            ACTIVES.Property,
            ACTIVES.Ground,
            ACTIVES.Another
        ] : []),
        ...(withDebit ? [ACTIVES.Debit] : [])
    ];

    const activesFieldsToSum = [
        "arrest",
        "evaluation",
        "realization_property",
        "price_reduction",
        "realization_sum_2",
        "return_sum"
    ];

    return db("meta")
        .select([...idFields, ...sumFields])
        .leftJoin("resolutions", "meta.inn", "resolutions.inn")
        .modify(joinActivesAndDebitTables)
        .modify(query => {
            activesFieldsToSum.forEach(field => {
                query.sumFieldsOfFewTables(tables, field);
            });
        })
        .whereIn("meta.inn", innList)
        .andWhere("meta.region", regionCode);
};


export const downloadSelectors = {
    getStatistics: async (regionCode, innList, isDerived) => {
        return {
            general: await buildCommonFieldsQuery(true, true, regionCode, innList),
            actives: await buildCommonFieldsQuery(true, false, regionCode, innList),
            debitor: await buildCommonFieldsQuery(false, true, regionCode, innList),
        };
    },
    getStatisticsIP: async (regionCode, innList) => {
        return db("meta")
            .selectFromTable("meta", [ "kno", "inn",  "name", ])
            .selectFromTable("resolutions", [
                "post_number",
                "post_date",
                "post_sum",
                "cur_debt",
                "exec_number",
                "exec_date",
            ])
            .nullToEmptyStr([ "esolutions.end_date",  "end_reason"])
            .reduceFlagsToStatusField("resolutions", "status_ip",flagsMapping)
            .leftJoin("resolutions", 'meta.inn', 'resolutions.inn')
            .whereIn("meta.inn", innList)
            .andWhere("meta.region", regionCode)
    }
}


export const getUserByIdOrLogin = async ({ id, login }) => {
    const identifier =
        [ null, undefined ].includes(id)  ? { username: login } : { id }

    const [ user ] = await db("users")
        .select(
            "id",
            "password   as passwordHash", 
            "name       as firstname",
            "surname    as secondname",
            "patronymic as lastname",
            "region     as regionCode",
            "role"
        )
        .where({ ...identifier })

    return user || null
}


export const fileStorage = {
    getDocuments: (source) => {
        return db("library").select("*").where({ source })
    },
    saveDocument: (data) => {
        return db("library").insert(data)
    }
}
