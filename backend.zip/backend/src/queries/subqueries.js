import db from "../connection.js"
import { ACTIVES } from '../types.js';


export const getResolutions =
    db("resolutions")
        .select("inn")
        .sumSafe("post_sum")
        .sumSafe("cur_debt")
        .countNotNull("end_date", "is_end")
        .countNotNull("stop_date", "is_stop")
        .countNotNull("pending_date", "is_pending")
        .countNotNull("terminate_date", "is_terminate")
        .sumSafe("is_archive")
        .sumSafe("is_derivative_debt")
        .max({ max_exec_date: "exec_date" })
        .groupBy("inn");


export const getActiveTable = tableName =>
        db(tableName)
            .select("inn")
            .sumSafe(tableName === "debit" ? "total_sum" : "cost")
            .sumSafe("arrest_sum")
            .sumSafe("evaluation_sum")
            .sumSafe("realization_sum_1")
            .sumSafe("price_reduction_sum")
            .sumSafe("realization_sum_2")
            .sumIfCheckedFieldNotNull("property_to_debtor_act", "property_to_debtor_sum")
            .sumIfCheckedFieldNotNull("dz_foreclose_date", "dz_foreclose_sum")
            .modify(query => { // ?
                if (["transport", "property"].includes(tableName)) {
                    query.where("status", "<>", 2)
                }
            })
            .groupBy("inn");


export const getActivesDetails = tableName => {
    // realization_result_№ - Дата отчета о реализации!,
    // realization_sum_№    - Результат реализации!
    const baseFields = [
        "id", "is_verified",
        "obj_status", "obj_status_manual",                                                // Статусы
        "arrest_propperty", "arrest_sum", "wanted_open", "wanted_close", "wanted_result", // Арест
        "evaluation_submit", "evaluation_accept", "evaluation_sum",                       // Оценка
        "realization_submit",                                                             // Передача на реализацию (всего)
        "realization_date_1", "realization_result_1", "realization_sum_1",                // Реализация, 1 этап
        "realization_property_sum", "not_realization_notification",                       // Результаты 1 этапа,
        "price_reduction_resolution", "price_reduction_sum",                              // Снижение цены
        "realization_date_2", "realization_result_2", "realization_sum_2",                // Реализация, 2 этап
        "not_realization_notification_2",                                                 // Уведомление о нереализации
        "property_to_debtor_act", "property_to_debtor_sum",                               // Передача имущества должнику
        "comment"
    ]

    const nonDebitFields = [
        "name", "cost",
        "lizing_name", "is_fns_lizing",
        "encumbrance_type", "encumbrance_date"
    ]

    const debitFields = [
        "name as debitor_names",
        "cost as total_sum",
        "date"
    ]

    return db(tableName)
        .select([
            ...baseFields,
            ...(tableName === ACTIVES.Debit ? debitFields : nonDebitFields)
        ])
}
