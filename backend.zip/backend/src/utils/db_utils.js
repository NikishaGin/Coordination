
/**
 * Фикс отсутсвия множественного RETURNING на mysql < 8,0.
 * Достраиывает ID шники вставленных записей по первому.
 */
export const fixInsertManyIdReturn = (id, insertNum) => 
    insertNum > 1 
        ?  Array.from({ length: insertNum }, (_, i) => id + i) 
        : [id]


export const phpToBcryptHash = hash => hash.replace(/^\$2y\$/, "$2a$")
