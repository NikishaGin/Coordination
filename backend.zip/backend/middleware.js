import db from './src/connection.js';
import { decodeToken, getUserByRequest } from './src/modules/user/services.js';


/**
 * TODO: Надо наладить инфраструктуру обработчиков ошибок.
 */

// ! НЕ убирать _
export const rootErrorHandler = (err, req, res, _) => {
    if (res.headersSent) return 

    console.error(err)
    res.status(500).json({ message: "Internal Server Error" })
}


const authenticateOrSendError = (req, res, next) => {
    const { isValid, payload } = decodeToken(req)
    const errMessage = "Authentication faild"

    if (!isValid) {
        res.status(401).json({ details: errMessage })
        next(new Error(errMessage))
    }

    return { isValid, payload }
} 


/**
 * Мидлварь для проверки авторизации,
 * отвечает ошибкой, если пользователь не авторизован.
 */
export const checkAuthMiddleware = (req, res, next) => {
    authenticateOrSendError(req, res, next)
    next()
}


/**
 * Мидлварь для проверки авторизации и получения данных пользователя.
 * Проверяет авторизацию и расширяет объект req объектом user 
 * с данными пользователя.
 */
export const getUserMiddleware = async (req, res, next) => {
    const { isValid } = authenticateOrSendError(req, res, next)
    if (!isValid) return
    
    const userData = getUserByRequest(req)
    if (!userData) {
        res.status(404).json({details: "User not found"})
    }
    
    req.user = userData
    next()
}